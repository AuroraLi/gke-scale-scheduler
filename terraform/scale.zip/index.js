const {ClusterManagerClient} = require('@google-cloud/container').v1;
// Instantiates a client
const containerClient = new ClusterManagerClient();

async function waitForOperation(projectId, operation) {
  while (operation.status !== 'DONE') {
    [operation] = await operationsClient.wait({
      operation: operation.name,
      project: projectId,
      zone: operation.zone.split('/').pop(),
    });
  }
}

/**
 * Starts Compute Engine instances.
 *
 * Expects a PubSub message with JSON-formatted event data containing the
 * following attributes:
 *  zone - the GCP zone the instances are located in.
 *  label - the label of instances to start.
 *
 * @param {!object} event Cloud Function PubSub message event.
 * @param {!object} callback Cloud Function PubSub callback indicating
 *  completion.
 */
exports.setSizePubSub = async (event, context, callback) => {
  try {
    const project = await containerClient.getProjectId();
    const payload = _validatePayload(event);
    const options = {
       filter: `labels.${payload.label}`,
       projectId: project,
       zone: payload.zone,
    };

    const [clusters] = await containerClient.listClusters(options);
    
    await Promise.all(
        clusters.map(async cluster => {
        const [response] = await containerClient.setNodePoolSize({
          projectId: project,
          zone: payload.zone,
          clusterID: cluster.name,
          nodeCount: payload.size,
          nodePoolID: payload.pool
        });

        return waitForOperation(project, response.latestResponse);
      })
    );

    // Operation complete. Instance successfully started.
    const message = 'Successfully resized';
    console.log(message);
    callback(null, message);
  } catch (err) {
    console.log(err);
    callback(err);
  }
};

/**
 * Validates that a request payload contains the expected fields.
 *
 * @param {!object} payload the request payload to validate.
 * @return {!object} the payload object.
 */
const _validatePayload = event => {
  let payload;
  try {
    payload = JSON.parse(Buffer.from(event.data, 'base64').toString());
  } catch (err) {
    throw new Error('Invalid Pub/Sub message: ' + err);
  }
  if (!payload.size) {
    throw new Error("Attribute 'size' missing from payload");
  } else if (!payload.zone) {
    throw new Error("Attribute 'zone' missing from payload");
  } else if (!payload.pool) {
    throw new Error("Attribute 'pool' missing from payload");
  } else if (!payload.label) {
    throw new Error("Attribute 'label' missing from payload");
  }
  return payload;
};